Contr�les : Manette de Xbox
Stick gauche : se d�placer
A : dasher
B : parer (s'oriente automatiquement vers l'enemi le plus proche)
X : attaquer (ne s'oriente pas automatiquement)

Note sur le prototype:
-Ce prototype pr�sente ce que sera le tutoriel du jeu (petite partie plateforme pour apprendre � dasher, puis un combat simple)
-Le combat n'est absolument pas finit, en particulier le comportement actuel du Gardien et la mort du joueur)
-Le comportement de l'IA est encore en construction mais l'id�e est l� : les mobs ne nous fonceront pas dessus tout le temps, ils attendront, selon leur comportement, le bon moment selon eux pour attaquer
-D�sol� � Emmanuel, j'ai oubli� de mettre une version apple, promis la prochaine fois j'y penserai, mais je suis vraiment d�sol�
